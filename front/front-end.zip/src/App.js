import './App.css';
import Navbar from './Navbar';
import { useEffect } from 'react';
import { useState } from 'react';
import UploadSuccess from './UploadSuccess.js';
import UploadImage from './UploadImage.js';
import { BrowserRouter as Router, Routes, Route} from "react-router-dom";
// 路由


function App() {
  const [WalletAddress, setWalletAddress] = useState("");
// 调用函数
  useEffect(()=>{
    // getWalletAddress();
  // 注释掉的原因是会自动连接钱包
  // 但是监听需要的是自动监听
  addwalletListener();
  },[]);
  

  // 还要加的一个功能是监听钱包地址切换
  function addwalletListener() {
    if(window.ethereum){
    window.ethereum.on('accountsChanged', (accounts) => {
      if (accounts.length > 0) {
        setWalletAddress(accounts[0]);
      }else{
        setWalletAddress("");
      }
    });
  }
}

  // 连接钱包
  const getWalletAddress = async () =>{
    if (window.ethereum) {
      try{
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        setWalletAddress(accounts[0]);
      }catch(error){
        console.log(error);
      }
    }
  };
     

  return (
    <div id="container">
    <Router>
      <Navbar onConnectWallet={getWalletAddress} walletAddress={WalletAddress}/>
      <Routes>
        <Route path="/" element={<UploadImage address={WalletAddress}/>} />
      </Routes>
     </Router>
    </div>
  );
};

export default App;


