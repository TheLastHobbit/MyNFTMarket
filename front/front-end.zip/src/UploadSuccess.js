function UploadSuccess(){
    return(
        <div>
            <h1>Upload Success</h1>
            <p>Check out your NFT on homepage</p>
        </div>
    )
}

export default UploadSuccess;